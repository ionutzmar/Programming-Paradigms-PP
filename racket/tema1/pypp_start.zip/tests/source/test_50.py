def main():
	s = 0
	for x in range(3):
		s += 3
