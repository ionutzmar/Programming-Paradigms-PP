def main():
	a = 3

	for x in [1, 2, 3]:
		for y in [3, 2, 1]:
			a += (x + y)
