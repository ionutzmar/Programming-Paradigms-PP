def main(a, b, c):
	a = (1, 2)
	b = "pp"
	c = 7
	d = None
