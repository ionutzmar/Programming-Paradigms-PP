def main():
	s = 0
	for x in range(10):
		s += x

	for y in range(5):
		s -= x

	for z in range(10):
		if z % 2 == 0:
			s += z
