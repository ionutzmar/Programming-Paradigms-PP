def main():
	a = (1, 2)
	b = 5
	c = (4, 5, 6, 7)
	d = 7
	e = "tema pp"
	f = 'p'
	g = 10.00
	return "ana are mere"
