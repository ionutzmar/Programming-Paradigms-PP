def main():
	i = 0
	j = 0

	while i == 10:
		i += 1
		j += 1
