def main(a):
	a = 5
	b = a
	a = 3
	c = 2
	d = c
	c = 7
	e = d
