def main():
	i = 10
	j = 0
	c = 0

	while i != j:
		i -= 1
		j += 1
		c += 2 
