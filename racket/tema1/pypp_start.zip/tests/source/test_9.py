def main(a):
	return a
