def main():
	return 2